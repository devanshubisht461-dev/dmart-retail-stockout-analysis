
# DMart Retail Stockout Analysis

## Project Overview

This capstone project investigates whether stockouts
are responsible for lower revenue at the Pune store.

## Business Scenario

Kavita Rao, Regional Operations Director, needs
evidence before investing in a stock-availability
programme.

## Part A: Data Foundation

- Data generation
- Data inspection
- Data cleaning
- Feature engineering
- Statistical analysis
- Executive summary

## Technology

- Python
- Pandas
- NumPy
- CSV datasets

## Analysis Period

1 April 2026 – 29 June 2026

## Important Note

All datasets are synthetic practice data and
do not represent actual DMart business records.
